const { getDefaultConfig } = require("expo/metro-config");
const path = require("path");

const config = getDefaultConfig(__dirname);
config.resolver = config.resolver ?? {};

config.resolver.blockList = [
  /node_modules\/pdf-parse[^/]*\/.*_tmp_.*/,
  /node_modules\/.pnpm\/vite@.*/,
  /node_modules\/.pnpm\/vitest@.*/,
  /.*\.test\.(ts|tsx|js|jsx)$/,
  /node_modules\/.pnpm\/@xmldom\+xmldom@.*/,
  /node_modules\/.pnpm\/mammoth@.*/,
  /node_modules\/.pnpm\/pdf-parse@.*/,
  /node_modules\/.pnpm\/plist@.*/,
];

const workspacePackages = {
  "@workspace/api-client-react": path.resolve(__dirname, "../../lib/api-client-react/src/index.ts"),
  "@workspace/api-zod": path.resolve(__dirname, "../../lib/api-zod/src/index.ts"),
};

config.resolver.resolveRequest = (context, moduleName, platform) => {
  if (workspacePackages[moduleName]) {
    return { filePath: workspacePackages[moduleName], type: "sourceFile" };
  }
  if (moduleName === "expo-secure-store") {
    return { filePath: path.resolve(__dirname, "shims/expo-secure-store.ts"), type: "sourceFile" };
  }
  if (
    moduleName === "./ExpoCryptoAES" &&
    context.originModulePath &&
    context.originModulePath.includes("expo-crypto") &&
    context.originModulePath.includes("/aes/")
  ) {
    return { filePath: path.resolve(__dirname, "shims/ExpoCryptoAES.js"), type: "sourceFile" };
  }
  if (
    moduleName === "mammoth" ||
    moduleName === "pdf-parse" ||
    moduleName === "plist" ||
    moduleName.includes("@xmldom/xmldom")
  ) {
    return { filePath: path.resolve(__dirname, "shims/server-only.js"), type: "sourceFile" };
  }
  return context.resolveRequest(context, moduleName, platform);
};

module.exports = config;
