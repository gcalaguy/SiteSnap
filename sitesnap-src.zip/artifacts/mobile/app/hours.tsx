import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  StyleSheet,
  Platform,
  ActivityIndicator,
  RefreshControl,
  TouchableOpacity,
  TextInput,
  Alert,
  Modal,
  KeyboardAvoidingView,
} from "react-native";
import DateTimePicker, { DateTimePickerEvent } from "@react-native-community/datetimepicker";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";
import {
  useListTimesheets,
  useListProjects,
  useGetMe,
  getListTimesheetsQueryKey,
  customFetch,
} from "@workspace/api-client-react";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import { useVoiceRecorder } from "@/hooks/useVoiceRecorder";

function isoFromDate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function formatDateLabel(iso: string): string {
  return new Date(iso + "T00:00:00").toLocaleDateString("en-CA", {
    weekday: "short", month: "short", day: "numeric", year: "numeric",
  });
}

const STATUS_COLORS: Record<string, string> = {
  draft: "#6B7280",
  submitted: "#3B82F6",
  approved: "#22C55E",
  denied: "#EF4444",
};

// Minimal 1x1 transparent PNG base64 data URL (exceeds server minLength 50)
const DUMMY_SIGNATURE =
  "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";

function formatWeekRange(startStr: string): string {
  const start = new Date(startStr);
  const end = new Date(start);
  end.setDate(start.getDate() + 6);
  const fmt = (d: Date) =>
    d.toLocaleDateString("en-CA", { month: "short", day: "numeric" });
  return `${fmt(start)} \u2013 ${fmt(end)}`;
}

export default function HoursScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { data: me } = useGetMe();
  const qc = useQueryClient();

  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editHours, setEditHours] = useState("");
  const [editDesc, setEditDesc] = useState("");

  // ── Log Hours modal state ─────────────────────────────────────────
  const [showLogModal, setShowLogModal] = useState(false);
  const [logProjectId, setLogProjectId] = useState<number | null>(null);
  const [logDate, setLogDate] = useState<Date>(new Date());
  const [logTempDate, setLogTempDate] = useState<Date>(new Date());
  const [showLogDatePicker, setShowLogDatePicker] = useState(false);
  const [logHoursVal, setLogHoursVal] = useState("");
  const [logDesc, setLogDesc] = useState("");
  const [logHoursError, setLogHoursError] = useState("");

  const resetLogForm = useCallback(() => {
    setLogProjectId(null);
    setLogDate(new Date());
    setLogHoursVal("");
    setLogDesc("");
    setLogHoursError("");
    setShowLogDatePicker(false);
  }, []);

  const openLogModal = useCallback(() => {
    resetLogForm();
    setShowLogModal(true);
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  }, [resetLogForm]);

  const logHoursMutation = useMutation({
    mutationFn: ({ projectId, date, hours, description }: { projectId: number; date: string; hours: number; description?: string }) =>
      customFetch(`/api/projects/${projectId}/time-entries`, {
        method: "POST",
        body: JSON.stringify({
          date,
          entries: [{ hours, description: description || undefined }],
        }),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: getListTimesheetsQueryKey() });
      setShowLogModal(false);
      resetLogForm();
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert("Hours Logged", "Your hours have been submitted for approval.");
    },
    onError: (err: any) => {
      const serverMsg: string | undefined = err?.data?.error ?? err?.message;
      const msg = serverMsg?.includes("not assigned")
        ? "You are not assigned to this project. Ask your foreman to add you."
        : "Failed to log hours. Please try again.";
      Alert.alert("Error", msg);
    },
  });

  const handleLogSubmit = useCallback(() => {
    setLogHoursError("");
    if (!logProjectId) {
      setLogHoursError("Please select a project.");
      return;
    }
    const h = parseFloat(logHoursVal);
    if (!logHoursVal || isNaN(h) || h <= 0 || h > 24) {
      setLogHoursError("Enter hours between 0.5 and 24.");
      return;
    }
    logHoursMutation.mutate({
      projectId: logProjectId,
      date: isoFromDate(logDate),
      hours: h,
      description: logDesc.trim() || undefined,
    });
  }, [logProjectId, logHoursVal, logDate, logDesc, logHoursMutation]);

  const onLogDateChange = useCallback((_event: DateTimePickerEvent, date: Date | undefined) => {
    if (Platform.OS === "android") {
      setShowLogDatePicker(false);
      if (date != null) setLogDate(date);
    } else if (date != null) {
      setLogTempDate(date);
    }
  }, []);

  // Voice recorder for the description field — appends each transcription
  const descVoice = useVoiceRecorder((text) => {
    if (text.trim()) setEditDesc((prev) => (prev ? `${prev} ${text.trim()}` : text.trim()));
  });

  const {
    data: timesheetsData,
    isLoading: tsLoading,
    refetch,
    isRefetching,
  } = useListTimesheets({
    status: statusFilter !== "all" ? statusFilter : undefined,
  });

  const { data: projectsData, isLoading: projLoading } = useListProjects();

  const timesheets = (timesheetsData ?? []) as any[];
  const projects = (projectsData ?? []) as any[];
  const loading = tsLoading || projLoading;

  // Group timesheets by project
  const byProject: Record<number, any[]> = {};
  const unassigned: any[] = [];
  for (const ts of timesheets) {
    const pid = ts.projectId ?? 0;
    if (pid === 0) unassigned.push(ts);
    else {
      if (!byProject[pid]) byProject[pid] = [];
      byProject[pid].push(ts);
    }
  }

  const totalHours = timesheets.reduce((s, ts) => s + (parseFloat(ts.totalHours) || 0), 0);
  const statuses = ["all", "draft", "submitted", "approved", "denied"];
  const topInset = Platform.OS === "web" ? 67 : insets.top;
  const isOwnerOrForeman = me?.role === "owner" || me?.role === "foreman";
  const canManage = me?.role === "owner";
  // Editing your own hours doesn't require owner/review privileges — the
  // backend already allows the timesheet's own user to PATCH it.
  const canEdit = (ts: any) => canManage || ts.userId === me?.id;

  const approveMutation = useMutation({
    mutationFn: (id: number) =>
      customFetch(`/api/timesheets/${id}/approve`, {
        method: "POST",
        body: JSON.stringify({ signatureData: DUMMY_SIGNATURE }),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: getListTimesheetsQueryKey() });
      Alert.alert("Approved", "Timesheet approved.");
    },
    onError: (err: any) => {
      const msg = err?.status === 409
        ? "Only submitted timesheets can be approved."
        : "Failed to approve timesheet.";
      Alert.alert("Error", msg);
    },
  });

  const denyMutation = useMutation({
    mutationFn: (id: number) =>
      customFetch(`/api/timesheets/${id}/deny`, {
        method: "POST",
        body: JSON.stringify({ notes: "" }),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: getListTimesheetsQueryKey() });
      Alert.alert("Rejected", "Timesheet rejected.");
    },
    onError: (err: any) => {
      const msg = err?.status === 409
        ? "Only submitted timesheets can be rejected."
        : "Failed to reject timesheet.";
      Alert.alert("Error", msg);
    },
  });

  const editMutation = useMutation({
    mutationFn: ({ id, body }: { id: number; body: { totalHours?: number; description?: string | null } }) =>
      customFetch(`/api/timesheets/${id}`, {
        method: "PATCH",
        body: JSON.stringify(body),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: getListTimesheetsQueryKey() });
      setEditingId(null);
      setEditHours("");
      setEditDesc("");
      Alert.alert("Updated", "Timesheet hours updated.");
    },
    onError: () => Alert.alert("Error", "Failed to update timesheet."),
  });

  const handleEdit = useCallback((ts: any) => {
    setEditingId(ts.id);
    setEditHours(ts.totalHours ?? "");
    setEditDesc(ts.description ?? "");
  }, []);

  const handleSaveEdit = useCallback((id: number) => {
    const h = parseFloat(editHours);
    if (!editHours || isNaN(h) || h <= 0 || h > 168) {
      Alert.alert("Invalid hours", "Enter hours between 0.5 and 168");
      return;
    }
    editMutation.mutate({ id, body: { totalHours: h, description: editDesc.trim() || null } });
  }, [editHours, editDesc, editMutation]);

  const renderEntryRow = (ts: any) => {
    const statusColor = STATUS_COLORS[ts.status] ?? "#6B7280";
    const isEditing = editingId === ts.id;

    return (
      <View key={ts.id} style={{ gap: 6 }}>
        <View style={styles.entryRow}>
          <Text style={[styles.entryWeek, { color: colors.mutedForeground }]}>
            {formatWeekRange(ts.weekStart)}
          </Text>
          {isEditing ? (
            <View style={{ flex: 1, gap: 6 }}>
              {/* Hours + save/cancel row */}
              <View style={{ flexDirection: "row", alignItems: "center", gap: 6, justifyContent: "flex-end" }}>
                <Text style={[styles.entryWeek, { color: colors.mutedForeground }]}>
                  {formatWeekRange(ts.weekStart)}
                </Text>
                <TextInput
                  value={editHours}
                  onChangeText={setEditHours}
                  keyboardType="decimal-pad"
                  style={[styles.editInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background }]}
                  autoFocus
                  accessibilityLabel="Edit hours"
                />
                <TouchableOpacity onPress={() => handleSaveEdit(ts.id)} accessibilityLabel="Save hours">
                  <Feather name="check" size={16} color="#22C55E" />
                </TouchableOpacity>
                <TouchableOpacity onPress={() => { setEditingId(null); setEditHours(""); setEditDesc(""); }} accessibilityLabel="Cancel edit">
                  <Feather name="x" size={16} color={colors.mutedForeground} />
                </TouchableOpacity>
              </View>
              {/* Description field with voice mic */}
              <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                <TextInput
                  value={editDesc}
                  onChangeText={setEditDesc}
                  placeholder="Add a note (optional)"
                  placeholderTextColor={colors.mutedForeground}
                  style={[
                    styles.descInput,
                    { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background },
                  ]}
                  accessibilityLabel="Hours description"
                  accessibilityHint="Optional note about this timesheet entry. Tap the mic to dictate."
                />
                <TouchableOpacity
                  onPress={() => {
                    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    void descVoice.toggle();
                  }}
                  accessibilityRole="button"
                  accessibilityLabel={descVoice.state === "recording" ? "Stop recording" : "Dictate note"}
                  accessibilityHint="Tap to record a voice note for this timesheet entry"
                  style={[
                    styles.micBtn,
                    {
                      backgroundColor: descVoice.state === "recording" ? "#EF444420" : `${colors.primary}15`,
                      borderColor: descVoice.state === "recording" ? "#EF4444" : colors.border,
                    },
                  ]}
                >
                  {descVoice.state === "transcribing" ? (
                    <ActivityIndicator size="small" color={colors.primary} />
                  ) : (
                    <Feather
                      name={descVoice.state === "recording" ? "mic-off" : "mic"}
                      size={14}
                      color={descVoice.state === "recording" ? "#EF4444" : colors.primary}
                    />
                  )}
                </TouchableOpacity>
              </View>
              {descVoice.error && (
                <Text style={{ fontSize: 11, color: "#EF4444", fontFamily: "Inter_400Regular" }}>
                  {descVoice.error}
                </Text>
              )}
            </View>
          ) : (
            <>
              <Text style={[styles.entryHours, { color: colors.foreground }]}>{ts.totalHours}h</Text>
              <View style={[styles.statusBadge, { backgroundColor: `${statusColor}18` }]}>
                <Text style={[styles.statusText, { color: statusColor }]}>{ts.status}</Text>
              </View>
            </>
          )}
        </View>

        {(canManage || (canEdit(ts) && !isEditing)) && (
          <View style={styles.actionRow}>
            {canManage && (
              <>
                <TouchableOpacity
                  style={[styles.actionBtn, { backgroundColor: "#22C55E15" }]}
                  onPress={() => {
                    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    approveMutation.mutate(ts.id);
                  }}
                  disabled={approveMutation.isPending}
                >
                  {approveMutation.isPending ? (
                    <ActivityIndicator size="small" color="#22C55E" />
                  ) : (
                    <>
                      <Feather name="check-circle" size={12} color="#22C55E" />
                      <Text style={[styles.actionText, { color: "#22C55E" }]}>Approve</Text>
                    </>
                  )}
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.actionBtn, { backgroundColor: "#EF444415" }]}
                  onPress={() => {
                    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    denyMutation.mutate(ts.id);
                  }}
                  disabled={denyMutation.isPending}
                >
                  {denyMutation.isPending ? (
                    <ActivityIndicator size="small" color="#EF4444" />
                  ) : (
                    <>
                      <Feather name="x-circle" size={12} color="#EF4444" />
                      <Text style={[styles.actionText, { color: "#EF4444" }]}>Reject</Text>
                    </>
                  )}
                </TouchableOpacity>
              </>
            )}
            {canEdit(ts) && !isEditing && (
              <TouchableOpacity
                style={[styles.actionBtn, { backgroundColor: `${colors.primary}15` }]}
                onPress={() => {
                  if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  handleEdit(ts);
                }}
                disabled={editMutation.isPending}
              >
                <Feather name="edit-2" size={12} color={colors.primary} />
                <Text style={[styles.actionText, { color: colors.primary }]}>Edit</Text>
              </TouchableOpacity>
            )}
          </View>
        )}
      </View>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topInset + 12, backgroundColor: colors.sidebar }]}>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>Hours Tracking</Text>
          <Text style={styles.headerSub}>
            {isOwnerOrForeman ? "All company hours" : "My tracked hours"}
          </Text>
        </View>
        <View style={[styles.badge, { backgroundColor: colors.primary }]}>
          <Text style={styles.badgeText}>{totalHours.toFixed(1)}h</Text>
        </View>
        <TouchableOpacity
          onPress={openLogModal}
          style={[styles.logBtn, { backgroundColor: "#FFFFFF20" }]}
          accessibilityRole="button"
          accessibilityLabel="Log hours"
          hitSlop={8}
        >
          <Feather name="plus" size={14} color="#FFFFFF" />
          <Text style={styles.logBtnText}>Log Hours</Text>
        </TouchableOpacity>
      </View>

      {/* Voice quick-log hint — points workers to the FAB mic */}
      <TouchableOpacity
        style={[styles.voiceHint, { backgroundColor: `${colors.primary}0D`, borderColor: `${colors.primary}30` }]}
        onPress={() => {
          if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          Alert.alert(
            "Log Hours by Voice",
            'Tap the mic button (bottom of screen) and say:\n\n"I worked 5 hours on Oak Street"\n\nor\n\n"Log 4 hours for Guy on Main Street"',
            [{ text: "Got it" }]
          );
        }}
        accessibilityRole="button"
        accessibilityLabel="Learn how to log hours by voice"
        accessibilityHint="Shows instructions for using the voice mic button to log hours hands-free"
      >
        <Feather name="mic" size={13} color={colors.primary} />
        <Text style={[styles.voiceHintText, { color: colors.primary }]}>
          Tip: tap the mic button and say "I worked 5 hours on Oak Street"
        </Text>
      </TouchableOpacity>

      {/* Status filter */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={[styles.filterRow, { borderBottomColor: colors.border }]}
        contentContainerStyle={{ paddingHorizontal: 16, gap: 8, paddingVertical: 10 }}
      >
        {statuses.map((s) => {
          const active = statusFilter === s;
          const color = s === "all" ? colors.primary : STATUS_COLORS[s] ?? colors.primary;
          return (
            <TouchableOpacity
              key={s}
              onPress={() => setStatusFilter(s)}
              style={[
                styles.filterChip,
                { borderColor: active ? color : colors.border, backgroundColor: active ? `${color}15` : colors.card },
              ]}
            >
              <Text style={[styles.filterChipText, { color: active ? color : colors.mutedForeground }]}>
                {s.charAt(0).toUpperCase() + s.slice(1)}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {/* List */}
      {loading ? (
        <View style={styles.loading}>
          <ActivityIndicator color={colors.primary} size="large" />
        </View>
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={isRefetching} onRefresh={refetch} tintColor={colors.primary} />}
          contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 24, gap: 12 }}
        >
          {/* Per-project cards */}
          {projects.map((p) => {
            const entries = byProject[p.id] ?? [];
            const projectHours = entries.reduce((s: number, ts: any) => s + (parseFloat(ts.totalHours) || 0), 0);
            if (entries.length === 0 && timesheets.length > 0) return null;

            return (
              <View key={p.id} style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <View style={styles.cardTop}>
                  <Text style={[styles.cardName, { color: colors.foreground }]} numberOfLines={1}>{p.name}</Text>
                  <Text style={[styles.cardTotal, { color: colors.primary }]}>{projectHours.toFixed(1)}h</Text>
                </View>
                {entries.length === 0 ? (
                  <Text style={[styles.cardEmpty, { color: colors.mutedForeground }]}>No timesheets yet</Text>
                ) : (
                  <View style={{ gap: 10, marginTop: 4 }}>
                    {entries.map((ts: any) => renderEntryRow(ts))}
                  </View>
                )}
              </View>
            );
          })}

          {/* Unassigned timesheets */}
          {unassigned.length > 0 && (
            <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={styles.cardTop}>
                <Text style={[styles.cardName, { color: colors.foreground }]}>Unassigned</Text>
                <Text style={[styles.cardTotal, { color: colors.primary }]}>
                  {unassigned.reduce((s, ts) => s + (parseFloat(ts.totalHours) || 0), 0).toFixed(1)}h
                </Text>
              </View>
              <View style={{ gap: 10, marginTop: 4 }}>
                {unassigned.map((ts) => renderEntryRow(ts))}
              </View>
            </View>
          )}

          {timesheets.length === 0 && (
            <View style={styles.empty}>
              <Feather name="clock" size={40} color={colors.border} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                {statusFilter !== "all" ? `No ${statusFilter} timesheets` : "No timesheets yet"}
              </Text>
            </View>
          )}
        </ScrollView>
      )}

      {/* ── Log Hours Modal ─────────────────────────────────────────── */}
      <Modal
        visible={showLogModal}
        animationType="slide"
        transparent
        onRequestClose={() => { setShowLogModal(false); resetLogForm(); }}
      >
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1 }}>
          <View style={styles.modalOverlay}>
            <View style={[styles.modalSheet, { backgroundColor: colors.card }]}>
              {/* Modal header */}
              <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
                <Text style={[styles.modalTitle, { color: colors.foreground }]}>Log Hours</Text>
                <TouchableOpacity onPress={() => { setShowLogModal(false); resetLogForm(); }} hitSlop={10}>
                  <Feather name="x" size={22} color={colors.foreground} />
                </TouchableOpacity>
              </View>

              <ScrollView
                style={{ flex: 1 }}
                contentContainerStyle={{ padding: 20, gap: 0, paddingBottom: insets.bottom + 24 }}
                keyboardShouldPersistTaps="handled"
              >
                {/* Project picker */}
                <Text style={[styles.fieldLabel, { color: colors.foreground }]}>
                  Project <Text style={{ color: "#EF4444" }}>*</Text>
                </Text>
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={{ gap: 8, paddingVertical: 4, marginBottom: 18 }}
                >
                  {(projects ?? []).map((p) => {
                    const active = logProjectId === p.id;
                    return (
                      <TouchableOpacity
                        key={p.id}
                        onPress={() => { setLogProjectId(p.id); setLogHoursError(""); }}
                        style={[
                          styles.projectChip,
                          {
                            backgroundColor: active ? colors.primary : colors.background,
                            borderColor: active ? colors.primary : colors.border,
                          },
                        ]}
                      >
                        <Text style={[styles.projectChipText, { color: active ? "#FFFFFF" : colors.foreground }]}>
                          {p.name}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                  {(projects ?? []).length === 0 && (
                    <Text style={{ color: colors.mutedForeground, fontSize: 13, fontFamily: "Inter_400Regular" }}>
                      No projects assigned yet.
                    </Text>
                  )}
                </ScrollView>

                {/* Date picker */}
                <Text style={[styles.fieldLabel, { color: colors.foreground }]}>
                  Date <Text style={{ color: "#EF4444" }}>*</Text>
                </Text>
                <TouchableOpacity
                  style={[styles.dateField, { backgroundColor: colors.background, borderColor: colors.border }]}
                  onPress={() => { setLogTempDate(logDate); setShowLogDatePicker(true); }}
                >
                  <Feather name="calendar" size={15} color={colors.primary} />
                  <Text style={[styles.dateFieldText, { color: colors.foreground }]}>
                    {formatDateLabel(isoFromDate(logDate))}
                  </Text>
                  <Feather name="chevron-down" size={14} color={colors.mutedForeground} />
                </TouchableOpacity>

                {/* Android date picker */}
                {showLogDatePicker && Platform.OS === "android" && (
                  <DateTimePicker
                    value={logDate}
                    mode="date"
                    display="default"
                    onChange={onLogDateChange}
                    maximumDate={new Date()}
                  />
                )}

                {/* iOS date picker in sheet */}
                {Platform.OS === "ios" && showLogDatePicker && (
                  <View style={[styles.iosDateBox, { backgroundColor: colors.background, borderColor: colors.border }]}>
                    <DateTimePicker
                      value={logTempDate}
                      mode="date"
                      display="spinner"
                      themeVariant="dark"
                      onChange={onLogDateChange}
                      maximumDate={new Date()}
                      style={{ width: "100%" }}
                    />
                    <View style={{ flexDirection: "row", justifyContent: "flex-end", paddingHorizontal: 12, paddingBottom: 8, gap: 16 }}>
                      <TouchableOpacity onPress={() => setShowLogDatePicker(false)}>
                        <Text style={{ color: colors.mutedForeground, fontFamily: "Inter_400Regular", fontSize: 14 }}>Cancel</Text>
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => { setLogDate(logTempDate); setShowLogDatePicker(false); }}>
                        <Text style={{ color: colors.primary, fontFamily: "Inter_700Bold", fontSize: 14 }}>Done</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                )}

                {/* Hours input */}
                <Text style={[styles.fieldLabel, { color: colors.foreground, marginTop: 18 }]}>
                  Hours Worked <Text style={{ color: "#EF4444" }}>*</Text>
                </Text>
                <TextInput
                  style={[
                    styles.textInput,
                    { backgroundColor: colors.background, borderColor: logHoursError ? "#EF4444" : colors.border, color: colors.foreground },
                  ]}
                  value={logHoursVal}
                  onChangeText={(t) => { setLogHoursVal(t); setLogHoursError(""); }}
                  placeholder="e.g. 8 or 7.5"
                  placeholderTextColor={colors.mutedForeground}
                  keyboardType="decimal-pad"
                  accessibilityLabel="Hours worked"
                />

                {/* Description input */}
                <Text style={[styles.fieldLabel, { color: colors.foreground, marginTop: 18 }]}>
                  Description{" "}
                  <Text style={{ fontSize: 11, fontFamily: "Inter_400Regular", color: colors.mutedForeground }}>optional</Text>
                </Text>
                <TextInput
                  style={[
                    styles.textInput,
                    styles.textInputMulti,
                    { backgroundColor: colors.background, borderColor: colors.border, color: colors.foreground },
                  ]}
                  value={logDesc}
                  onChangeText={setLogDesc}
                  placeholder="What did you work on?"
                  placeholderTextColor={colors.mutedForeground}
                  multiline
                  numberOfLines={3}
                  accessibilityLabel="Work description"
                />

                {!!logHoursError && (
                  <Text style={{ color: "#EF4444", fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 6 }}>
                    {logHoursError}
                  </Text>
                )}

                {/* Submit button */}
                <TouchableOpacity
                  style={[
                    styles.submitBtn,
                    { backgroundColor: colors.primary, opacity: logHoursMutation.isPending ? 0.7 : 1, marginTop: 24 },
                  ]}
                  onPress={handleLogSubmit}
                  disabled={logHoursMutation.isPending}
                  accessibilityRole="button"
                  accessibilityLabel="Submit hours"
                >
                  {logHoursMutation.isPending ? (
                    <ActivityIndicator color="#FFFFFF" size="small" />
                  ) : (
                    <Text style={styles.submitBtnText}>Submit Hours for Approval</Text>
                  )}
                </TouchableOpacity>
              </ScrollView>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 14,
  },
  headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold", color: "#FFFFFF" },
  headerSub: { fontSize: 12, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.6)", marginTop: 1 },
  badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  badgeText: { fontSize: 12, fontFamily: "Inter_700Bold", color: "#111111" },
  filterRow: { borderBottomWidth: 1 },
  filterChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
  },
  filterChipText: { fontSize: 13, fontFamily: "Inter_500Medium" },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  empty: { alignItems: "center", justifyContent: "center", paddingVertical: 60, gap: 10 },
  emptyText: { fontSize: 16, fontFamily: "Inter_600SemiBold" },
  card: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    gap: 6,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 3,
    elevation: 1,
  },
  cardTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  cardName: { fontSize: 15, fontFamily: "Inter_600SemiBold", flex: 1 },
  cardTotal: { fontSize: 15, fontFamily: "Inter_700Bold" },
  cardEmpty: { fontSize: 13, fontFamily: "Inter_400Regular", marginTop: 2 },
  entryRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  entryWeek: { fontSize: 12, fontFamily: "Inter_400Regular", flex: 1 },
  entryHours: { fontSize: 12, fontFamily: "Inter_600SemiBold", width: 42 },
  statusBadge: { paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 },
  statusText: { fontSize: 10, fontFamily: "Inter_600SemiBold" },
  editInput: {
    width: 60,
    height: 28,
    borderRadius: 6,
    borderWidth: 1,
    paddingHorizontal: 6,
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
  },
  descInput: {
    flex: 1,
    height: 32,
    borderRadius: 6,
    borderWidth: 1,
    paddingHorizontal: 8,
    fontSize: 12,
    fontFamily: "Inter_400Regular",
  },
  micBtn: {
    width: 32,
    height: 32,
    borderRadius: 8,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  voiceHint: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginHorizontal: 16,
    marginTop: 10,
    marginBottom: 2,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
  },
  voiceHintText: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    flex: 1,
  },
  actionRow: {
    flexDirection: "row",
    gap: 8,
    marginTop: 2,
    paddingLeft: 0,
  },
  actionBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  actionText: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
  },
  logBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 16,
    marginLeft: 10,
  },
  logBtnText: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
    color: "#FFFFFF",
  },
  // Log Hours Modal
  modalOverlay: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(0,0,0,0.45)",
  },
  modalSheet: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: "90%",
    minHeight: 480,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  modalTitle: {
    fontSize: 17,
    fontFamily: "Inter_700Bold",
  },
  fieldLabel: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
    marginBottom: 8,
  },
  projectChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
  },
  projectChipText: {
    fontSize: 13,
    fontFamily: "Inter_500Medium",
  },
  dateField: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    marginBottom: 4,
  },
  dateFieldText: {
    flex: 1,
    fontSize: 14,
    fontFamily: "Inter_500Medium",
  },
  iosDateBox: {
    borderRadius: 10,
    borderWidth: 1,
    overflow: "hidden",
    marginTop: 6,
    marginBottom: 8,
  },
  textInput: {
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },
  textInputMulti: {
    minHeight: 70,
    textAlignVertical: "top",
    paddingTop: 10,
  },
  submitBtn: {
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  submitBtnText: {
    color: "#FFFFFF",
    fontSize: 15,
    fontFamily: "Inter_700Bold",
  },
});
